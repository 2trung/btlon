#include<iostream>
#include<string>
#include"dinhnghiaham.h"
#define TONGKH 100

using namespace std;

int main(){
	khachhang kh[TONGKH];
	int stt, soNha;
	string fileName = "";
	string ten;
	int nhap;
	bool tieptuc = true;
	do{
		cout << "************************ MENU ****************************\n";
        cout << "*           1. Them khach hang tu ban phim.              *\n";
        cout << "*           2. Them khach hang tu file.                  *\n";
        cout << "*           3. In ds khach hang ra man hinh.             *\n";
        cout << "*           4. In ds khach hang ra file.                 *\n";
        cout << "*           5. Sua thong tin khach hang.                 *\n";
        cout << "*           6. Tim kiem khach hang theo ten.             *\n";
        cout << "*           7. Tim kiem khach hang theo so nha.          *\n";
        cout << "*           8. Xoa thong tin khach hang.                 *\n";
        cout << "*           9. Thong ke.                                 *\n";
        cout << "*           0. Thoat.                                    *\n";
        cout << "**********************************************************\n";
        cout << "Nhap tuy chon: ";
        cin >> nhap;
        switch (nhap){
        	case 1:
        		system("cls");
        		themKH(kh);
        		break;
        	case 2:
        		system("cls");
        		cout << "Nhap dia chi file: ";
				cin >> fileName; 
        		themTuFile(kh, fileName);
        		break;
        	case 3:
        		system("cls");
        		inDS(kh);
        		break;
        	case 4:
        		system("cls");
        		cout << "Nhap dia chi file: ";
				cin >> fileName;
        		inRaFile(kh, fileName);
        		break;
			case 5:
				system("cls");
        		cout << "Nhap so thu tu cua khach hang can sua: ";
				cin >> stt;
				suaThongTin(kh, stt);
        		break;
			case 6:
				system("cls");
        		cout << "Nhap ten can tim kiem: ";
        		cin.ignore();
        		getline(cin, ten);
				timKiem(kh, ten);
        		break;
			case 7:
				system("cls");
        		cout << "Nhap so nha: ";
				cin >> soNha;
				timSoNha(kh, soNha);
				break;
			case 8:
				system("cls");
        		cout << "Nhap so thu tu cua khach hang can xoa: ";
				cin >> stt;
				xoaThongTin(kh, stt);
        		break;
			case 9:
				system("cls");
        		thongKe(kh);
        		break;
			case 0:
				system("cls");
        		tieptuc = false;
        		break;
			default:
				cout << "\nKhong co chuc nang nay!";
            	cout << "\nHay chon chuc nang trong hop menu.";
				break;	
    	}
    	pressAnyKey();
	}while(tieptuc);
	return 0;
}




