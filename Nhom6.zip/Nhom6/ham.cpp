#include<iostream>
#include<fstream>
#include <iomanip>
#include <string>
#include<bits/stdc++.h>
#include <locale>
#include<conio.h>
#define TONGKH 100

using namespace std;

struct khachhang{
	string hoten;
	int soNha;
	float sodien[12];
	float tongSoDien;
	float tongTienDien;
};

struct g3 : numpunct<char> {
    	char do_thousands_sep()   const { return '.';  } 
    	string do_grouping() const { return "\3"; }
};

int tongKH(khachhang kh[]){
	int tongKh = 0;
	for (int i = 0; i < TONGKH; i++){
		if (!kh[i].hoten.empty())
			tongKh ++;
	}
	return tongKh;
}

void tinhTongSoDien(khachhang &kh){
	for (int thang = 0; thang < 12; thang++)
		kh.tongSoDien += kh.sodien[thang];
	return;
}
void tinhTongTienDien(khachhang &kh){
	int bac1 = 1678, bac2 = 1734, bac3 = 2014, bac4 = 2536, bac5 = 2834, bac6 = 2927;
	for (int thang = 0; thang < 12; thang++)
		if(kh.sodien[thang] <= 50)
			kh.tongTienDien += kh.sodien[thang]*bac1;
		else if(kh.sodien[thang] <= 100)
			kh.tongTienDien += 50*bac1 + ((kh.sodien[thang]-50)*bac2);
		else if(kh.sodien[thang] <= 200)
			kh.tongTienDien += 50*bac1 + (50*bac2) + ((kh.sodien[thang]-100)*bac3);
		else if(kh.sodien[thang] <= 300)
			kh.tongTienDien += 50*bac1 + (50*bac2) + (100*bac3) + ((kh.sodien[thang]-200)*bac4);
		else if(kh.sodien[thang] <= 400)
			kh.tongTienDien += 50*bac1 + (50*bac2) + (100*bac3) + (100*bac4) + ((kh.sodien[thang]-300)*bac5);
		else if(kh.sodien[thang] > 400)
			kh.tongTienDien += 50*bac1 + (50*bac2) + (100*bac3) + (100*bac4) + (100*bac5) + ((kh.sodien[thang]-400)*bac6);
	return;
}

void themKH(khachhang kh[]){
	int stt = tongKH(kh);
	cout << "Nhap ten KH: ";
	cin.ignore();
	getline(cin, kh[stt].hoten);
	cout << "Nhap so nha: ";
	cin >> kh[stt].soNha;
	for (int thang = 0; thang < 12; thang ++){
		cout << "Nhap so dien thang " << thang + 1 << ": ";
		cin >> kh[stt].sodien[thang];
	}
	tinhTongSoDien(kh[stt]);
	tinhTongTienDien(kh[stt]);			
	return;
}

void themTuFile(khachhang kh[], string filename){
	fstream fileIn(filename.c_str(), ios::in);
	if (!fileIn.is_open())
		cout << "Khong tim thay file!\n";
	else{
		int soKHTrongFile;
		fileIn >> soKHTrongFile;
		for (int stt = tongKH(kh); stt < soKHTrongFile + tongKH(kh); stt++){
			while (!fileIn.eof()){
				fileIn.ignore();
				getline(fileIn, kh[stt].hoten);
				fileIn >> kh[stt].soNha;
				for (int thang = 0; thang < 12; thang ++)
					fileIn >> kh[stt].sodien[thang];
				break;
			}
			tinhTongTienDien(kh[stt]);
			tinhTongSoDien(kh[stt]);	
		}
		cout << "Nhap tu file thanh cong!\n";
	}
	fileIn.close();	
	return;
}

void inDS(khachhang kh[]){
	cout << "STT" << setw(22) << "Ten KH" << setw(12) << "So nha\t";
	for (int i = 1; i < 13; i++){
		cout << "T" << i << "\t"; 
	}
	cout << endl << "-------------------------------------------------------------------------------------------------------------------------------------------" << endl;	
	for (int stt = 0; stt < tongKH(kh); stt++){
		cout << stt + 1 << setw(25) << kh[stt].hoten << "\t" << kh[stt].soNha ;
		for (int thang = 0; thang < 12; thang ++)
			cout << "\t" << kh[stt].sodien[thang];
		cout << endl;
	}	
	return;	
}

void inRaFile(khachhang kh[], string fileName){
	fstream fileOut(fileName.c_str(), ios::out);
	if (!fileOut.is_open())
		cout << "Khong tim thay file!\n";
	else{
		fileOut << tongKH(kh) << endl;
		for (int stt = 0; stt < tongKH(kh); stt++){
			fileOut << kh[stt].hoten << "\n" << kh[stt].soNha;
			for (int thang = 0; thang < 12; thang ++)
				fileOut << " " << kh[stt].sodien[thang];
			fileOut << endl;
		}
		cout << "In ra file thanh cong!\n";	
	}	
	return;
}

void suaThongTin(khachhang kh[], int stt){
	if (stt < 1 || stt > tongKH(kh))
		cout << "So thu tu khong hop le!";
	else{
		cout << "Nhap ten KH: ";
		cin.ignore();
		getline(cin, kh[stt - 1].hoten);
		cout << "Nhap so nha: ";
		cin >> kh[stt].soNha;
		for (int thang = 0; thang < 12; thang ++){
			cout << "Nhap so dien thang " << thang + 1 << ": ";
			cin >> kh[stt - 1].sodien[thang];
		}
		tinhTongSoDien(kh[stt - 1]);
		tinhTongTienDien(kh[stt - 1]);
	}
	return;
}

void timKiem(khachhang kh[], string s){
	bool found = false;
	cout << "STT" << setw(22) << "Ten KH" << setw(12) << "So nha\t";
		for (int i = 1; i < 13; i++)
			cout << "T" << i << "\t"; 
	cout << endl << "-------------------------------------------------------------------------------------------------------------------------------------------" << endl;
	for (int stt = 0; stt <= tongKH(kh); stt++){
		
		transform(s.begin(), s.end(), s.begin(), ::tolower);
		string hoten = kh[stt].hoten;
		transform(hoten.begin(), hoten.end(), hoten.begin(), ::tolower);
		if (hoten.find(s) < hoten.length()){
			found = true;
			cout << stt + 1 << setw(25) << kh[stt].hoten<< "\t" << kh[stt].soNha;
			for (int thang = 0; thang < 12; thang ++)
				cout << "\t" << kh[stt].sodien[thang];
			cout << endl;		
		}
	}
	if (!found){
		system("cls");
		cout << "Khong tim thay ten vua nhap! ";
	}
		
	return;
}

void timSoNha(khachhang kh[], int soNha){
	bool found = false;
	for (int stt = 0; stt <= tongKH(kh); stt++){
		if (soNha == kh[stt].soNha){
			found = true;
			cout << "STT" << setw(22) << "Ten KH" << setw(12) << "So nha\t";
			for (int i = 1; i < 13; i++)
				cout << "T" << i << "\t"; 
			cout << endl << "-------------------------------------------------------------------------------------------------------------------------------------------" << endl;
			cout << stt + 1 << setw(25) << kh[stt].hoten << "\t" << kh[stt].soNha;
			for (int thang = 0; thang < 12; thang ++)
				cout << "\t" << kh[stt].sodien[thang];
			cout << "\n\n";;		
		}
	}
	if (!found)
		cout << "Khong tim thay so nha vua nhap!\n";
}

void xoaThongTin(khachhang kh[], int stt){
	if (stt < 1 || stt > tongKH(kh))
		cout << "So thu tu khong hop le!";
	else{
		for(int i = stt - 1; i < TONGKH-1; i++) 
        	kh[i] = kh[i+1];
        	cout << "Xoa khach hang co so thu tu " << stt << " thanh cong!\n";
    }	
    return;
}


khachhang KHMax(khachhang kh[]){
	float *max;
	max = &kh[0].tongSoDien;
	for (int stt = 0; stt < tongKH(kh); stt++){
		if (kh[stt].tongSoDien > *max)
			max = &kh[stt].tongSoDien;	
	}
	for (int stt = 0; stt < tongKH(kh); stt++){
		if (max == &kh[stt].tongSoDien)
			return kh[stt];
	}
}
khachhang KHMin(khachhang kh[]){
	float *min;
	min = &kh[0].tongSoDien;
	for (int stt = 0; stt < tongKH(kh); stt++){
		if (kh[stt].tongSoDien < *min)
			min = &kh[stt].tongSoDien;	
	}
	for (int stt = 0; stt < tongKH(kh); stt++){
		if (min == &kh[stt].tongSoDien)
			return kh[stt];
	}
}

int thangMax(khachhang kh[]){
	float tongSoDienThang[12];
	for (int thang = 0; thang < 12; thang++){
		for (int stt = 0; stt <= tongKH(kh); stt++){
				tongSoDienThang[thang] += kh[stt].sodien[thang];		
		}
	}
	float *max = & tongSoDienThang[0];
	for (int thang = 0; thang < 12; thang++){
		if (*max < tongSoDienThang[thang])
			max = &tongSoDienThang[thang];
	}
	for (int thang = 0; thang < 12; thang++){
		if (max == &tongSoDienThang[thang])
			return thang+1;
	}
}

int thangMin(khachhang kh[]){
	float tongSoDienThang[12];
	for (int thang = 0; thang < 12; thang++){
		for (int stt = 0; stt < tongKH(kh); stt++){
			tongSoDienThang[thang] += kh[stt].sodien[thang];		
		}
	}
	float *min = & tongSoDienThang[0];
	for (int thang = 0; thang < 12; thang++){
		if (*min > tongSoDienThang[thang])
			min = &tongSoDienThang[thang];
	}
	for (int thang = 0; thang < 12; thang++){
		if (min == &tongSoDienThang[thang])
			return thang+1;
	}
}


float soDienTbThang(khachhang kh[]){
	float tongSoDien;
	for (int stt = 0; stt < tongKH(kh); stt++){
		for (int thang = 0; thang < 12; thang++){
			tongSoDien += kh[stt].sodien[thang];
		}
	}
	return tongSoDien / 12 / tongKH(kh);
}

void sapXep(khachhang kh[]){
	khachhang khSort[TONGKH], khTemp;
	for (int i = 0; i < tongKH(kh); i++) {
        khSort[i] = kh[i];
    }
    for (int j = 0; j < tongKH(kh); j++){
    	for (int k = tongKH(kh); k > j; k--){
    		if (khSort[j].tongSoDien < khSort[k].tongSoDien){
    			khTemp = khSort[j];
    			khSort[j] = khSort[k];
    			khSort[k] = khTemp;
			}
		}
	}	
	cout << "\nSTT" << setw(22) << "Ten KH" << setw(25) << "Tong so dien (kWh)" << setw(25) << "Tong tien dien (VND)";
	cout << endl << "-----------------------------------------------------------------------------------" << endl;
	cout.imbue(locale(cout.getloc(), new g3));
	for (int stt = 0; stt < tongKH(kh); stt++)
		cout << stt + 1 << setw(25) << khSort[stt].hoten << "\t\t" << setprecision(12) << khSort[stt].tongSoDien << "\t\t" << khSort[stt].tongTienDien << endl; 
	
    return;
}

void thongKe(khachhang kh[]){
	cout << "THONG KE TRONG 12 THANG" << "\n\n";
	cout << "- Tong khach hang su dung dien: " << tongKH(kh) << endl;
	cout << "- Khach hang su dung nhieu dien nhat: " << KHMax(kh).hoten << ", da su dung " <<  KHMax(kh).tongSoDien << " so dien" << endl;
	cout << "- Khach hang su dung it dien nhat: " << KHMin(kh).hoten << ", da su dung " <<  KHMin(kh).tongSoDien << " so dien" << endl;
	cout << "- Thang su dung nhieu dien nhat: thang " << thangMax(kh) << endl;
	cout << "- Thang su dung it dien nhat: thang " << thangMin(kh) << endl;
	cout << "- So dien trung binh 1 khach hang su dung tren thang: " << soDienTbThang(kh) << endl;
	sapXep(kh);
	
	return;
}

void pressAnyKey() {
    cout << "\n\nBam phim bat ky de tiep tuc...";
    getch();
    system("cls");
    return;
}
