#include <string>
using namespace std;

struct khachhang{
	string hoten;
	int soNha;
	float sodien[12];
	float tongSoDien;
	float tongTienDien;
};

int tongKH(khachhang[]);
void tinhTongSoDien(khachhang&);
void tinhTongTienDien(khachhang&);
void themKH(khachhang[]);
void themTuFile(khachhang[], string);
void inDS(khachhang[]);
void inRaFile(khachhang[], string);
void suaThongTin(khachhang[], int);
void timKiem(khachhang[], string);
void timSoNha(khachhang[], int);
void xoaThongTin(khachhang[], int);
khachhang KHMax(khachhang[]);
khachhang KHMin(khachhang[]);
int thangMin(khachhang[]);
float soDienTbThang(khachhang[]);
void sapXep(khachhang[]);
void thongKe(khachhang[]);
void pressAnyKey();

